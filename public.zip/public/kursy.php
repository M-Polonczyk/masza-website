<?php

$content = $_SERVER['DOCUMENT_ROOT'].'/../resources/pages/courses.php';
include $_SERVER['DOCUMENT_ROOT'].'/../resources/layout/layout.php';

?>