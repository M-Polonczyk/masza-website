<?php

$content = $_SERVER['DOCUMENT_ROOT'].'/../resources/pages/offer.php';
include $_SERVER['DOCUMENT_ROOT'].'/../resources/layout/layout.php';

?>