<section id="Translations" class="p-0 p-md-3">
    <div class="container">
        <p>
        CJR MASZA oferuje tłumaczenia pisemne specjalistyczne oraz zwykłe. Wycena tłumaczenia jest bezpłatna, a koszt zależy od liczby znaków (jedna strona rozliczeniowa to 1800 znaków ze spacjami), stopnia trudności przesłanego tekstu, występowania w tekście fragmentów identycznych bądź podobnych oraz terminu wykonania. Podane niżej ceny są orientacyjne.
        </p>

        <?php include $_SERVER['DOCUMENT_ROOT'].'/../resources/partials/translation-prices-table.php'; ?>
    </div>
</section>