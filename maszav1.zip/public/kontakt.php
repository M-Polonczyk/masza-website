<?php

$content = $_SERVER['DOCUMENT_ROOT'].'/../resources/pages/contact.php';
include $_SERVER['DOCUMENT_ROOT'].'/../resources/layout/layout.php';

?>