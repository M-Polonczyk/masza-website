<?php

$content = $_SERVER['DOCUMENT_ROOT'].'/../resources/pages/home.php';
include $_SERVER['DOCUMENT_ROOT'].'/../resources/layout/layout.php';

?>