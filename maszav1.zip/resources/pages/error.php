<section class="p-0 p-md-3">
    <div class="container">
        <p>
            Ups, wystąpił błąd. Przepraszamy za niedogodności. Nasi rosyjscy przyjaciele postarają się zdiagnozować problem i go naprawić.
        </p>
        <p class="text-danger">
            <?= $errorMessage ?>
        </p>
    </div>
</section>