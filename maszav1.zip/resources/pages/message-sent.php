<section class="p-0 p-md-3">
    <div class="container">
        <p>
            Dziękujemy za wysłanie wiadomości. Zwykle odpowiadamy w przeciągu kilku godzin. Postaramy się sprawnie :-)
        </p>
    </div>
</section>